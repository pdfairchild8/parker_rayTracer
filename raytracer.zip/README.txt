1. Parker Fairchild
2. Dalton, Ben
3. All Required Tasks
Art Contest
Checkered-Box
Soft Shadows
Spotlight
Orthographic
4. My art contest submission is an interest bug I found. I find the gray shadows and the single corrupted side of the box really interesting.

"I consent to have my art contest submission posted publicly on the class web site. My name/pseudonym for public display is Parker Fairchild. 
5. I think at least 20 hours if you count both submissions.
6. This was a great assignment. I wish I had time to do more of the tasks.
7. N/A